package useless;
import java.util.List;
import org.springframework.stereotype.Service;
@Service
public interface ProductService {

	       
	      
	     

			List<Product> findAll();

			List<Product> viewAllProduct();

			void addProduct(Product theProduct);

			void updateProduct(Product theProduct);

			String deleteProduct(int theproductId);

			Product viewProduct(int theproductId);

			Product findById(int theproductId);

			void save(Product product);

			String deleteByproductId(int theproductId);


		

			
}
