package useless;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
public interface CartService {
	public List<Cart> findAll();
	
	public void saveCart(Cart cart);
	
	public void updateCart(Cart cart);

	
}
