package useless;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.shopping.demoshopping.service.CartService;

@Controller
@RequestMapping("/cart")
public class CartRestController {
	@SuppressWarnings("unused")
	private CartService cartservice;
	
	
	public CartRestController(CartService theCartservice) {
		cartservice = theCartservice;
		}
	
	@PostMapping("/cart")
	public Cart addCart(@RequestBody Cart cart) {
		
		cartservice.saveCart(cart);
		
		return cart;
	}
	@PutMapping("/cart")
	public Cart updateCart(@RequestBody Cart cart) {
		
		cartservice.updateCart(cart);
		
		return cart;
	}

}
