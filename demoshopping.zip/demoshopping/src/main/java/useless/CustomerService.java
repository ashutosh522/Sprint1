package useless;

import java.util.List;

import org.springframework.stereotype.Service;

import com.shopping.demoshopping.entity.Customer;


@Service
public interface CustomerService {
	public List<Customer> findAll();
	
	public Customer findById(int id);
	
	public void save(Customer theCustomer);
	
	public void deleteById(int id);	

}
