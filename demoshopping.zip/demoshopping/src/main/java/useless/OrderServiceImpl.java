package useless;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopping.demoshopping.dao.OrderRepository;
import com.shopping.demoshopping.entity.Order;

@Service
public class OrderServiceImpl implements OrderService {
	
	private OrderRepository orderRepository;
	
	@Autowired
	public OrderServiceImpl(OrderRepository theOrderRepository) {
		orderRepository = theOrderRepository;
	}

	@Override
	public List<Order> findAll() {
		return orderRepository.findAll();
	}

	@Override
	public Order findById(int orderId) {
		Optional<Order> result = orderRepository.findById(orderId);
		
		Order theOrder = null;
		
		if (result.isPresent()) {
			theOrder = result.get();
		}
		else {
			// we didn't find the employee
			throw new RuntimeException("Did not find order id - " + orderId);
		}
		
		return theOrder;
	}

	@Override
	public void save(Order theOrder) {
		orderRepository.save(theOrder);
	}

	@Override
	public void deleteById(int orderId) {
		orderRepository.deleteById(orderId);

	}

	@Override
	public void update(Order order) {
		orderRepository.update(order);
		
	}

}
