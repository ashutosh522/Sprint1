package useless;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SuppressWarnings("unused")
@RestController
@RequestMapping("/api")
public class UserRestController {
	private UserService userservice;
	
	@Autowired
	public UserRestController(UserService userservice) {
		this.userservice = userservice;
	}
	
	@GetMapping("/user/{userId}")
	public 	User getUser(@PathVariable int id) {
		
		User theUser = 	userservice.findById(id);
		
		if (theUser == null) {
			throw new RuntimeException("User not found - " + id);
		}
		
		return theUser;
	}
	@PostMapping("/user")
	public User addUser(@RequestBody User theUser) {
		
		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update
		
		//theAddress.setAddressId(0);
		
		userservice.save(theUser);
		
		return theUser;
	}
	@PutMapping("/user")
	public User updateUser(@RequestBody User theUser) {
		
		userservice.save(theUser);
		
		return theUser;
	}
	@DeleteMapping("/user/{userId}")
	public String deleteUser(@PathVariable int id) {
		
		User tempUser = userservice.findById(id);
		
		// throw exception if null
		
		if (tempUser == null) {
			throw new RuntimeException("Could not found User - " + id);
		}
		
		userservice.deleteById(id);
		
		return "Deleted Customer id - " + id;
	}
}
