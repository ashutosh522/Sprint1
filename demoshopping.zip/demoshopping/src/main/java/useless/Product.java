package useless;
import java.util.Objects;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor; 
import lombok.NoArgsConstructor; 
import lombok.ToString;


@NoArgsConstructor
@AllArgsConstructor
@ToString

@Entity
@Table(name ="product")
public class Product {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name ="productId")
    private int productId;
     
	@Column(name ="productName")
    private String productName;
	
	@Column(name ="price")
    private double price;
	
	@Column(name ="colour")
    private String colour;
	
	@Column(name ="dimensions")
    private String dimensions;
	
	@Column(name ="specifications")
    private String specifications;
	
	@Column(name ="manufacturer")
    private String manufacturer;
	
	@Column(name ="quantity")
    private int quantity;
	
	@Column(name ="category")
    private Category category;

	public int getproductId() {
		return productId;
	}

	public void setproductId(int productId) {
		this.productId = productId;
	}

	public String getproductName() {
		return productName;
	}

	public void setproductName(String productName) {
		this.productName= productName;
	}

	public double getprice() {
		return price;
	}

	public void setprice(double price) {
		this.price = price;
	}

	public String getdimensions() {
		return dimensions;
	}

	public void setdimensions(String dimensions) {
		this.dimensions = dimensions;
	}

	public String getspecifications() {
		return specifications;
	}

	public void setspecifications(String specifications) {
		this.specifications = specifications;
	}

	public String getmanufacturer() {
		return manufacturer;
	}

	public void setmanufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public int getquantity() {
		return quantity;
	}

	public void setquantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public int hashCode() {
		return Objects.hash(productName, price, quantity, dimensions, colour, productId, category, specifications, manufacturer);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		return Objects.equals(productName, other.productName) && Objects.equals(dimensions, other.dimensions)
				&& Objects.equals(colour, other.colour) && productId == other.productId && Objects.equals(quantity, other.quantity)
				&& Objects.equals(specifications, other.specifications) && Objects.equals(manufacturer, other.manufacturer) 
				&& Objects.equals(category, other.category) && Objects.equals(price, other.price);
	}
	
	
}
