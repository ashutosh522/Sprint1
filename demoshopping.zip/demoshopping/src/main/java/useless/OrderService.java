package useless;

import java.util.List;
import org.springframework.stereotype.Service;
import com.shopping.demoshopping.entity.Order;
@Service
public interface OrderService {
	public List<Order> findAll();
	
	public Order findById(int orderId);
	
	public void save(Order theOrder);
	
	public void deleteById(int orderId);	
	
	public void update(Order order);

}
