package useless;

import java.util.List;

import org.springframework.stereotype.Service;
@Service
public interface UserService {
	public List<User> findAll();
	public void addUser(User theUser);
	public void removeUser(User theUser);
	public void validateUser(User theUser);
	public void signOut(User theUser);
} 