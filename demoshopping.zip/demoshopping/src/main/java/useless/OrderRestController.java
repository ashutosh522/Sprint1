package useless;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.shopping.demoshopping.entity.Order;
import com.shopping.demoshopping.service.OrderService;




@SuppressWarnings("unused")
@RestController
@RequestMapping("/api")

public class OrderRestController {
	
	private OrderService orderservice;
	
	@Autowired
	public OrderRestController(OrderService theOrderservice) {
		orderservice = theOrderservice;
	}

	@GetMapping("/order")
	public List<Order> findAll() {
		return orderservice.findAll();
	}
	@GetMapping("/order/{orderId}")
	public Order getOrder(@PathVariable int orderId) {
		
		Order theOrder = orderservice.findById(orderId);
		
		if (theOrder == null) {
			throw new RuntimeException("Order id not found - " + orderId);
		}
		
		return theOrder;
	}
	@PostMapping("/order")
	public Order addOrder(@RequestBody Order theOrder) {
		
		// also just in case they pass an id in JSON ... set id to 0
		// this is to force a save of new item ... instead of update
		
		//theAddress.setAddressId(0);
		orderservice.save(theOrder);
		
		return theOrder;
	}
	@PutMapping("/order")
	public Order updateOrder(@RequestBody Order order) {
		
		orderservice.save(order);
		
		return order;
	}
	@DeleteMapping("/order/{OrderId}")
	public String deleteOrder(@PathVariable int orderId) {
		
		Order tempOrder = orderservice.findById(orderId);
		
		// throw exception if null
		
		if (tempOrder == null) {
			throw new RuntimeException("Order is not found - " + orderId);
		}
		
		orderservice.deleteById(orderId);
		
		return "Deleted order id - " + orderId;
	}
}
