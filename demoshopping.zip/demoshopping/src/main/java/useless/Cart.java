package useless;

import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import useless.Product;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString 
@Entity
@Table(name ="cart")
	public class Cart {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name ="cartid")
    private int cartId;
	
	@OneToOne
    private Customer customer;

	@OneToOne
    private Map<Product, Integer> product;
}
