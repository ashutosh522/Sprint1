package useless;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ProductServiceImpl implements ProductService {

private ProductRepository ProductRepository;

@Autowired
public ProductServiceImpl(ProductRepository ProductRepository) {
this.ProductRepository = ProductRepository;
}

@Override
public List<Product> viewAllProduct() {
return ProductRepository.findAll();
}

@Override
public Product viewProduct(int theproductId) {
Optional<Product> result = ProductRepository.findById(null);

Product theProduct = null;

if (result.isPresent()) {
theProduct = result.get();
} else {
// we didn't find the Product
throw new RuntimeException("Did not find Product id - " + theproductId);
}

return theProduct;
}


@Override
public void addProduct(Product theProduct) {
ProductRepository.save(theProduct);
}

@Override
public void updateProduct(Product theProduct) {
ProductRepository.save(theProduct);
}


@Override
public String deleteProduct(int theproductId) {
ProductRepository.deleteById(theproductId);
return null;
}


@Override
public List<Product> findAll() {
	// TODO Auto-generated method stub
	return null;
}


@Override
public Product findById(int theproductId) {
	// TODO Auto-generated method stub
	return null;
}

@Override
public void save(Product product) {
	// TODO Auto-generated method stub
	
}

@Override
public String deleteByproductId(int theproductId) {
	// TODO Auto-generated method stub
	return null;
}



}