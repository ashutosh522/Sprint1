package useless;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopping.demoshopping.dao.CartRepository;

@Service
public class CartServiceImpl implements CartService {
	
	private CartRepository cartRepository;
	
	@Autowired
	public CartServiceImpl(CartRepository theCartRepository) {
		this.cartRepository = theCartRepository;
		}
	

	@Override
	public List<Cart> findAll() {
		return cartRepository.findAll();
	}


	@Override
	public void saveCart(Cart cart) {
		cartRepository.save(cart);
       
	}

	@Override
	public void updateCart(Cart cart) {
		 cartRepository.update(cart);
	}

}
