package useless;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

public class UserServiceImpl implements UserService {
	
	private UserRepository userRepository;
	
	@Autowired
	public UserServiceImpl(UserRepository userRepository) {
		this.userRepository=userRepository;
	}
	@Override
	public List<User> findAll() {
		return userRepository.findAll();
	}

	@Override
	public void addUser(User theUser) {
		userRepository.save(theUser);

	}

	@Override
	public void removeUser(User theUser) {
		userRepository.deleteById(theUser.getId());

	}

	@Override
	public void validateUser(User theUser) {
		userRepository.validateUser(User theUser);
	}

	@Override
	public void signOut(User theUser) {
		userRepository.signOut(theUser.getId());

	}

} 