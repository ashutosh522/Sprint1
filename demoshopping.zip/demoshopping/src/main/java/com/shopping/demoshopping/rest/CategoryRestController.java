package com.shopping.demoshopping.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shopping.demoshopping.entity.Category;
import com.shopping.demoshopping.service.CategoryService; 

@RestController
@RequestMapping("/cat")
public class CategoryRestController {
	private CategoryService categoryService;

	
	@Autowired
	public CategoryRestController(CategoryService categoryService) {
		this.categoryService = categoryService;
	}
	
	
	@GetMapping("/category")
	public List<Category> findAll(){
		return categoryService.findAll();
	}
	@GetMapping("/category/{theId}")
	public Category findById(@PathVariable int theId) {
		return categoryService.findById(theId);
	}
	
	@PostMapping("/category")
	public void addCategory(@RequestBody Category category) {
		category.setCatId(0);
		categoryService.save(category);
	}
	
	@PutMapping("/category")
	public void updateCategory(@RequestBody Category category) {
		categoryService.save(category);
	}
	
	@DeleteMapping("/category/{theId}")
	public String deleteById(@PathVariable int theId) {
		return categoryService.deleteById(theId);
	}
}