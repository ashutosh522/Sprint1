package com.shopping.demoshopping.service;
import java.util.List;
import org.springframework.stereotype.Service;
import com.shopping.demoshopping.entity.Product;
@Service
public interface ProductService {
	
		public List<Product> viewAllProduct();
		
		public Product viewProduct(int theId);
			
		public void addProduct(Product theProduct);
		  
	    public void updateProduct(Product theProduct);
			
		public void deleteProduct(int theId);
		  
		public Product viewProduct(String commonName);

	    public List<Product> viewAllProductByType(String typeOfProduct );

}

