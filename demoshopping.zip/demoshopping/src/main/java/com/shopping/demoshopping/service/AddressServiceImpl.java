package com.shopping.demoshopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopping.demoshopping.dao.AddressRepository;
import com.shopping.demoshopping.entity.Address;

@Service
public class AddressServiceImpl implements AddressService {
	
	private AddressRepository addressRepository;
	
	@Autowired
	public AddressServiceImpl(AddressRepository addressRepository) {
		this.addressRepository = addressRepository;
	}


	@Override
	public void addAddress(Address theAddress) {
		theAddress.setId(0);
		addressRepository.save(theAddress);
    }

	@Override
	public void updateAddress(Address theAddress) {
		addressRepository.save(theAddress);
         
	}

	@Override
	public void removeAddress(Address theAddress) {
		addressRepository.deleteById(theAddress.getId());	
	}


	@Override
	public Address viewAllAddress(int id) {
		List<Address> listAddress = addressRepository.findAll();
		Address  address = null;
		for(Address ad : listAddress) {
			if(id== ad.getId())
				address=ad;
		}
		return address;
	}


	@Override
	public Address viewAddress(Address theAddress) {
		List<Address> listAddress = addressRepository.findAll();
		Address  address = null;
		System.out.println(theAddress);
		for(Address ad : listAddress) {
			System.out.println(ad);
			if(theAddress.equals(ad))
				address=theAddress;
		}
		return address;
	}

	@Override
	public List<Address> findAll() {
		return addressRepository.findAll();	
	}
}
