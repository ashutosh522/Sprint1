package com.shopping.demoshopping.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shopping.demoshopping.entity.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

	Optional<Product> findByCommonName(String commonName);

	Optional<Product> findByTypeOfProduct(String typeOfProduct);
	
}
