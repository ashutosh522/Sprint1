package com.shopping.demoshopping.entity;

import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor; 
import lombok.NoArgsConstructor; 
import lombok.ToString;


@NoArgsConstructor
@AllArgsConstructor
@ToString

@Entity
@Table(name ="address")
public class Address {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name ="id")
    private int id;
     
	@Column(name ="streetno")
    private String streetNo;
	
	@Column(name ="buildingname")
    private String buildingName;
	
	@Column(name ="city")
    private String city;
	
	@Column(name ="state")
    private String state;
	
	@Column(name ="country")
    private String country;
	
	@Column(name ="pincode")
    private String pinCode;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getStreetNo() {
		return streetNo;
	}

	public void setStreetNo(String streetNo) {
		this.streetNo = streetNo;
	}

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	@Override
	public int hashCode() {
		return Objects.hash(buildingName, city, country, id, pinCode, state, streetNo);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		return Objects.equals(buildingName, other.buildingName) && Objects.equals(city, other.city)
				&& Objects.equals(country, other.country) && id == other.id && Objects.equals(pinCode, other.pinCode)
				&& Objects.equals(state, other.state) && Objects.equals(streetNo, other.streetNo);
	}
	
	
}
