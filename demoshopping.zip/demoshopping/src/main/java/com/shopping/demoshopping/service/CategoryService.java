package com.shopping.demoshopping.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.shopping.demoshopping.entity.Category;

@Service
public interface CategoryService {
	public List<Category> findAll();
	public Category findById(int theId);
	public void save(Category category);
	public String deleteById(int theId);
}
