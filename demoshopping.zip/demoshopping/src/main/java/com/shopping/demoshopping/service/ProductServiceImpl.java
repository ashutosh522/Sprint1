package com.shopping.demoshopping.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.shopping.demoshopping.dao.ProductRepository;
import com.shopping.demoshopping.entity.Product;

@Service
public class ProductServiceImpl implements ProductService {

	private ProductRepository ProductRepository;

	@Autowired
	public ProductServiceImpl(ProductRepository ProductRepository) {
		this.ProductRepository = ProductRepository;
	}

	@Override
	public List<Product> viewAllProduct() {
		return ProductRepository.findAll();
	}

	@Override
	public Product viewProduct(int theId) {
		Optional<Product> result = ProductRepository.findById(theId);

		Product theProduct = null;

		if (result.isPresent()) {
			theProduct = result.get();
		} else {
			
			throw new RuntimeException("Did not find Product id - " + theId);
		}

		return theProduct;
	}
	
	
	@Override
	public void addProduct(Product theProduct) {
		ProductRepository.save(theProduct);
	}
	
	@Override
	public void updateProduct(Product theProduct) {
		ProductRepository.save(theProduct);
	}
	

	@Override
	public void deleteProduct(int theId) {
		ProductRepository.deleteById(theId);
	}
	
	
	@Override
	public Product viewProduct(String  commonName) {
		Optional<Product> result = ProductRepository.findByCommonName(commonName);

		Product theProduct = null;

		if (result.isPresent()) {
			theProduct = result.get();
		} else {
			
			throw new RuntimeException("Did not find Product CommonName - " + commonName);
		}

		return theProduct;
	}

	

	@Override
	public List<Product> viewAllProductByType(String typeOfProduct) {
		Optional<Product> result = ProductRepository.findByTypeOfProduct(typeOfProduct);
	
		Product theProduct = null;

		if (result.isPresent()) {
			theProduct = result.get();
		} else {
			
			throw new RuntimeException("Did not find Product By Type- " + typeOfProduct);
		}

		return ProductRepository.findAll();
	}

}