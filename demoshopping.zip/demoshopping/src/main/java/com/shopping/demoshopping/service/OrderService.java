package com.shopping.demoshopping.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.shopping.demoshopping.entity.Order;


	@Service
	public interface OrderService {
		  public List<Order> viewAllOrder();
			
		  public Order viewOrder(int theId);
			
		  public void addOrder(Order theProductt);
		  
	      public void updateOrder(Order theProduct);
			
		  public void deleteOrder(int theId);
	}
