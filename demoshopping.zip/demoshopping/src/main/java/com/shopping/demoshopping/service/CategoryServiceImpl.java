package com.shopping.demoshopping.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.shopping.demoshopping.dao.CategoryRepository;
import com.shopping.demoshopping.entity.Category;

@Service
public class CategoryServiceImpl implements CategoryService {

	CategoryRepository categoryRepository;
	
	public CategoryServiceImpl(CategoryRepository categoryRepository) {
		this.categoryRepository= categoryRepository;
	}

	@Override
	public List<Category> findAll() {
		// TODO Auto-generated method stub
		return categoryRepository.findAll();
	}

	@Override
	public Category findById(int theId) {
		// TODO Auto-generated method stub
		Optional<Category> result= categoryRepository.findById(theId);
		Category cat =null;
		if(result.isPresent())
			cat = result.get();
		else
			throw new RuntimeException("Did not find Category : " + theId);
		return cat;
	}

	@Override
	public void save(Category category) {
		categoryRepository.save(category);
	}

	@Override
	public String deleteById(int theId) {
		 categoryRepository.deleteById(theId);
		 return "Id deleted : "+ theId;
	}
}
