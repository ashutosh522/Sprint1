package com.shopping.demoshopping.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.shopping.demoshopping.entity.Product;
import com.shopping.demoshopping.service.ProductService;

@RestController
public class ProductRestController {
	private ProductService productService;

	@Autowired
	public ProductRestController(ProductService productService) {
		this.productService = productService;
	}


	@GetMapping("/productt")
	public List<Product> findAll() {
		return productService.viewAllProduct();
	}


	@GetMapping("/product/{productId}")
	public Product getProduct(@PathVariable int ProductId) {
		
		Product theProduct = productService.viewProduct(ProductId);
		
		if (theProduct == null) {
			throw new RuntimeException("Product id not found - " + ProductId);
		}
		
		return theProduct;
	}



	@PostMapping("/product")
	public Product addProduct(@RequestBody Product theProduct) {
		
		//theProduct.setProductId(0);
		
		productService.addProduct(theProduct);
		
		return theProduct;
	}

	@PutMapping("/product")
	public Product updateProduct(@RequestBody Product theProduct) {
		
		productService.updateProduct(theProduct);
		
		return theProduct;
	}

	@DeleteMapping("/product/{productId}")
	public String deleteProduct(@PathVariable int ProductId) {
		
		Product tempProduct = productService.viewProduct(ProductId);
		
		// throw exception if null
		
		if (tempProduct == null) {
			throw new RuntimeException("Product id not found - " + ProductId);
		}
		
		productService.deleteProduct(ProductId);
		
		return "Deleted Product id - " + ProductId;
	   }
	
	@GetMapping("/product/{CommonName}")
	public Product getProductByCommonName(@PathVariable String commonName) {
		
		Product theProduct = productService.viewProduct(commonName);
		
		if (theProduct == null) {
			throw new RuntimeException("Product  not found - " + commonName);
		}
		
		return theProduct;
	}
	
	@GetMapping("/product/{typeOfProduct}")
	public List<Product> findAllProduct(@PathVariable String typeOfProduct) {
		return productService.viewAllProductByType(typeOfProduct);
	}
}