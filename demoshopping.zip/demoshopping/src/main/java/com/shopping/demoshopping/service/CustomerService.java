package com.shopping.demoshopping.service;


import java.util.List;

import org.springframework.stereotype.Service;

import com.shopping.demoshopping.entity.Customer;
@Service
public interface CustomerService {
	public List<Customer> viewAllCustomer();
		
	  public Customer viewCustomer(int theId);
		
	  public void addCustomer(Customer theCustomer);
	  
      public void updateCustomer(Customer theCustomer);
		
	  public void deleteCustomer(int theId);
	

}
