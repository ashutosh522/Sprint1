package com.shopping.demoshopping.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.shopping.demoshopping.entity.Address;
@Service
public interface AddressService {
	
	public List<Address> findAll();
	public void addAddress(Address theAddress);
	public void updateAddress(Address theAddress);
	public void removeAddress(Address theAddress);
	public Address viewAllAddress(int id);
	public Address viewAddress(Address theAddress);	
}
