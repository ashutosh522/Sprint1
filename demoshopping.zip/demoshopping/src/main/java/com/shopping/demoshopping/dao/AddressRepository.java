package com.shopping.demoshopping.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.shopping.demoshopping.entity.Address;

public interface AddressRepository extends JpaRepository<Address, Integer> {

}
