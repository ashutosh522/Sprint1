package com.shopping.demoshopping.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shopping.demoshopping.entity.Address;
import com.shopping.demoshopping.service.AddressService;


@SuppressWarnings("unused")
@RestController
@RequestMapping("/addr")
public class AddressRestController {
	private AddressService addressService;

	
	@Autowired
	public AddressRestController(AddressService theAddressservice) {
		this.addressService = theAddressservice;
	}
	
	@PostMapping("/address")
	public Address addAddress(@RequestBody Address address) {		
		address.setId(0);
		addressService.addAddress(address);
		return address;
	}
	
	@PutMapping("/address")
	public Address updateAddress(@RequestBody Address theAddress) {
		addressService.addAddress(theAddress);
		return theAddress;
	}
	
	@DeleteMapping("/address")
	public String removeAddress(@RequestBody Address address) {
		addressService.removeAddress(address);
		return "Deleted address id - " + address.getId();
	}
	
	@GetMapping("/address/{addressId}")
	public Address viewAllAddress(@PathVariable int addressId) {
		return addressService.viewAllAddress(addressId);
	}
	
	@GetMapping("/address")
	public Address viewAddress(@RequestBody Address address) {
		return addressService.viewAddress(address);
	}
	 
}